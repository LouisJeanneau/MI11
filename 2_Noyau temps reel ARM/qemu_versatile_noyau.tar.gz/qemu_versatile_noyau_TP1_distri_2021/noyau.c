/*----------------------------------------------------------------------------*
 * fichier : noyau.c                                                          *
 * mini noyau temps reel fonctionnant sur MC9328MXL                           *
 * ce fichier definit toutes les fonctions du noyau                           *
 *----------------------------------------------------------------------------*/
#include <stdint.h>

#include "serialio.h"
#include "versatile_timer.h"
#include "versatile_interrupt.h"
#include "noyau_file.h"
#include "noyau.h"

/*----------------------------------------------------------------------------*
 * variables internes du noyau                                                *
 *----------------------------------------------------------------------------*/

/*
 * compteur d'activation de chaque tache
 */
static int compteurs[MAX_TACHES];
/*
 * tableau stockant le contexte de chaque tache
 */
CONTEXTE _contexte[MAX_TACHES];
/*
 * numero de la tche en train d'etre executee
 */
volatile uint16_t _tache_c;
/*
 * mémorisation de l'adresse du sommet de la pile après chaque allocation d'un 
 * espace de pile à une tâche
 */
uint32_t _tos;
/*
 * variable d'acquittement du timer
 * = 1 s'il faut acquitter le timer
 */
int _ack_timer = 1;

/*----------------------------------------------------------------------------*
 * fonctions du noyau                                                         *
 *----------------------------------------------------------------------------*/

/*
 * termine l'execution du noyau
 * entre  : sans
 * sortie : sans
 * description : termine l'execution du noyau, execute en boucle une
 *               instruction vide
 */
void noyau_exit(void) {
    printf("Sortie du noyau\n");
    /* Q23 : desactivation des interruptions */
    
    /* affichage du nombre d'activation de chaque tache !*/
    uint16_t j;
    for (j = 0; j < MAX_TACHES; j++)
        printf("\nActivations tache %d : %d", j, compteurs[j]);
	/* Q24 : Que faire quand on termine l'execution du noyau ? */
    
}

/*
 * termine l'execution d'une tache
 * entre  : sans
 * sortie : sans
 * description : une tache dont l'execution se termine n'est plus executee
 *               par le noyau
 *               cette fonction doit etre appelee a la fin de chaque tache
 */
void fin_tache(void) {
    /* Q25 : on interdit les interruptions */
    
    /* Q26 : la tache est enlevee de la file des taches */
    
}

/*
 * demarrage du system en mode multitache
 * entre  : adresse de la tache a lancer
 * sortie : sans
 * description : active la tache et lance le scheduler
 */
void start(TACHE_ADR adr_tache) {
    short j;
    register unsigned int sp asm("sp");
															  
														  
    /* Q27 : initialisation de l'etat des taches */
    for (j = 0; j < MAX_TACHES; j++) {
        
    }
    /* Q28 : initialisation de la tache courante */
	_tache_c = ????;
    /* initialisation de la file circulaire de gestion des tâches */
	file_init();
    /* Q29 : initialisation de la variable _tos sommet de la pile */
    _tos = ????;
    /* Q210 : passage en mode IRQ */
    
    /* Q211 : initialisation du pointeur de pile du mode IRQ */
    
    /* Q212 : passage en mode SYS */
    
    /* Q213 : on interdit les interruptions */
    
    /* Q214 : initialisation du timer a 100 Hz soit une période de 10ms */
	
    /* Q215 : initialisation du gestionnaire matériel d'interruption */
    
    /* creation et activation de la premiere tache */
    active(cree(adr_tache));
}

/*
 * creation d'une nouvelle tache
 * entre  : adresse de la tache a creer
 * sortie : numero de la tache cree
 * description : la tache est creee en lui allouant une pile et un numero
 *               en cas d'erreur, le noyau doit etre arrete
 */
uint16_t cree(TACHE_ADR adr_tache) {
    /* pointeur d'une case de _contexte */
    CONTEXTE *p;
    /* Q216 : numero de la derniere tache creee */
    static uint16_t tache = -1;
    /* Q217: debut section critique */
    
    /* Q218 : generation du numero de la tache suivante */
    
    /* Q219 : arret du noyau si plus de MAX_TACHES^*/
    
	
	
    /* creation du contexte de la nouvelle tache */
    p = &_contexte[tache];
    /* Q220 : allocation d'une pile a la tache */
    
	/* Q221 : decrementation du pointeur de pile general, afin que la prochaine tache
	 * n'utilise pas la pile allouee pour la tache courante */
	
    /* Q222 : fin section critique */
	
    /* Q223 : memorisation de l'adresse de debut de la tache */
    
	/* Q224 : mise a jour de l'etat de la tache a CREE */
    
    return (tache);
}

/*
 * ajout d'une tache pouvant etre executee a la liste des taches eligibles
 * entre  : numero de la tache a ajouter
 * sortie : sans
 * description : ajouter la tache dans la file d'attente des taches eligibles
 *               en cas d'erreur, le noyau doit etre arrete
 */
void active(uint16_t tache) {
    /* acces au contexte de la tache */
    CONTEXTE *p = &_contexte[tache];
    /* Q225 : verifie que la tache n'est pas dans l'etat NCREE, sinon arrete le noyau*/
    
	
    }
	/* Q226 : debut section critique */
    
    /* Q227 : activation de la tache seulement si elle est a l'état CREE */
    if (p->status == CREE) {
        /* mise a jour de l'etat de la tache a PRET */
        
        /* ajoute la tache a la file des taches eligibles */
        
        /* lancement du scheduler */
        
    }
    /* Q228 : fin section critique */
    
}

/*
 * lancement du scheduler pour selectionner une nouvelle tache a executer
 * entre  : sans
 * sortie : sans
 * description : provoque une commutation de tache
 */
void schedule(void) {
    /* Q229 : debut section critique */
	
	/* Q230 : on simule une exception IRQ pour forcer un appel correct au scheduler */
    _ack_timer = ????;
	/* Q231 : passage en mode d'exception IRQ */
    
	/* Q232 : code assembleur pour simuler une interruption */
    __asm__ __volatile__(
            /* sauvegarde de cpsr dans spsr */
            
            
            /* sauvegarde de pc dans lr an ajustant sa valeur */
            
            /* saut au scheduler */
            
    );
    /* Q233 : passage en mode system */
    
    /* Q234 : fin de section critique */
    
}
/*
 * endort la tache courante
 * entre  : sans
 * sortie : sans
 * description : endort la tache courante et lance l'execution d'une nouvelle
 *               tache
 */
void dort(void) {
    
	
}

/*
 * reveille une tache
 * entre  : numero de la tache a reveiller
 * sortie : sans
 * description : reveille une tache
 *               en cas d'erreur, le noyau doit etre arrete
 */
void reveille(uint16_t t) {
    
	
}

/*-----------------------------------------------------------------------------*
 *                  ORDONNANCEUR preemptif optimise                            *
 *                                                                             *
 *             !! Cette fonction doit s'executer en mode IRQ !!                *
 *  !! Pas d'appel direct ! Utiliser schedule pour provoquer une commutation !!*
 *----------------------------------------------------------------------------*/
void __attribute__((naked)) scheduler(void) {
    register CONTEXTE *p;
    /* pointeur de pile */
    register unsigned int sp asm("sp");
    /* Q235 : sauvegarde le contexte complet sur la pile IRQ de la tache courante */
    __asm__ __volatile__(
            /* sauvegarde des registres du mode system sur la pile IRQ */
            
            /* attente d'un cycle pour eviter d'ecraser des donnees */
            
            /* ajustement du pointeur de pile  IRQ*/
            
            /* sauvegarde du contexte spsr et de lr IRQ sur la pile IRQ */
            
            
    );
	/* Q236 : reinitialisation du timer si necessaire */
    if (_ack_timer) {
        
    } else {
        
    }
    /* Q237 : initialise le pointeur de pile IRQ de la tache courante a la position
       actuelle du pointeur de pile */
    
    /* Q238 : recherche la prochaine tache a executer */
    _tache_c = ????;
    /* Q239 : verifie qu'une tache suivante existe, sinon arret du noyau */
    
        
		
    
    /* on bascule sur la nouvelle tache a executer */
    /* incrémentation du compter d'activation de la nouvelle tache */
    compteurs[_tache_c]++;
    /* Q240 : le pointeur p pointe sur le contexte de la nouvelle tache courante */
    
    /* Q241 : on verifie que la tache est dans l'etat PRET, si oui, on la charge
       si non, elle est deja en cours d'execution donc on restaure la valeur
       de sp pour preparer la restauration du contexte */
    if (p->status == PRET) {
        /* charger sp avec la valeur initiale contenue dans le contexte */
        
        /* passage en mode SYS */
        
        /* charger sp pour le systeme */
        
        /* mise a jour du statut de la tache en EXEC */
        
        /* autoriser les interruptions */
        
        /* lancement de la tache */
        
    } else {
		/* commutation de contexte par l'intermédiaire d'une commutation du pointeur de pile */
        
    }
    /* Q242 restauration du contexte complet de la tache depuis la pile IRQ de la
       tache */
    __asm__ __volatile__(
            /* restauration du contexte spsr et de lr */
            
			
            /* restauration des registres du mode system */
            
            /* attente d'un cycle pour eviter d'ecraser des donnees */
            
            /* ajustement du pointeur de pile IRQ */
            
            /* ajustement de lr pour faire un retour d'exception */
            
    );
}

